﻿CREATE TABLE [dbo].[request_interested]
(
	[Id] INT PRIMARY KEY, 
	[id_patient] INT NOT NULL,
	[description] VARCHAR(200) NOT NULL,
	CONSTRAINT [FK_request_interest_registration_interested] FOREIGN KEY ([id_patient]) REFERENCES [dbo].[registration_interested]([Id]), 
)
