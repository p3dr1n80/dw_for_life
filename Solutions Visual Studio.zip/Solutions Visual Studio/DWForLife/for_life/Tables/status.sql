﻿CREATE TABLE [dbo].[status]
(
	[Id] INT NOT NULL PRIMARY KEY,
	[status] VARCHAR(15) NOT NULL
)
