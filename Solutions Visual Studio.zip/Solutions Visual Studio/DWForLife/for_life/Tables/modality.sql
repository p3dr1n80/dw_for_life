﻿CREATE TABLE [dbo].[modality]
(
	[Id] INT NOT NULL PRIMARY KEY,
	[name] VARCHAR(30) NOT NULL
)
