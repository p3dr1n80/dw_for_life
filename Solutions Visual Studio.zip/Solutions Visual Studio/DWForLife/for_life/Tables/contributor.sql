﻿CREATE TABLE [dbo].[contributor]
(
	[Id] INT NOT NULL PRIMARY KEY,
	[contributor] VARCHAR(100) NOT NULL,
	[cnpj] VARCHAR(50) NOT NULL,
	[donation] MONEY NOT NULL,
	[email] VARCHAR(100) UNIQUE NOT NULL,
	[cell_phone] VARCHAR(15) NULL,
	[segment] VARCHAR(30) NOT NULL,
	[zip_code] VARCHAR(10) NOT NULL,
	[address] VARCHAR(80) NOT NULL,
	[number] INT NOT NULL,
	[district] VARCHAR(80) NOT NULL,
	[city] VARCHAR(30) NOT NULL,
	[state] VARCHAR(2) NOT NULL,
	[year_donation] INT NOT NULL
)
