﻿CREATE TABLE [dbo].[employee_level]
(
	[Id] INT NOT NULL PRIMARY KEY,
	[level] VARCHAR(50) NOT NULL,
	[remuneration] INT NOT NULL
)
