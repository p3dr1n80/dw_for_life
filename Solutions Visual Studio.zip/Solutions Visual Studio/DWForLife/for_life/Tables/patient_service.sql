﻿CREATE TABLE [dbo].[patient_service]
(
	[Id] INT NOT NULL PRIMARY KEY, 
    [patient_id] INT NOT NULL, 
    [responsible_id] INT NOT NULL,
    [observation] VARCHAR(200) NULL,
    [modality] INT NOT NULL,
    [created_at] DATETIME DEFAULT GETDATE(), 
    CONSTRAINT [FK_patient_service_modality] FOREIGN KEY ([modality]) REFERENCES [dbo].[modality]([Id])
)
