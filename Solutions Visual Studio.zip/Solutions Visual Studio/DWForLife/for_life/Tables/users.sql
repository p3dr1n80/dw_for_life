﻿CREATE TABLE [dbo].[users]
(
	[Id] INT NOT NULL PRIMARY KEY, 
    [name] VARCHAR(80) NOT NULL, 
    [email] VARCHAR(80) UNIQUE NOT NULL, 
    [password] VARCHAR(100) NOT NULL, 
    [level] INT NOT NULL,
    [crm] VARCHAR(50) NULL,
    [speciality] INT NULL,
    [created_at] DATETIME DEFAULT(GETDATE()) NOT NULL, 
    CONSTRAINT [FK_users_speciality] FOREIGN KEY ([speciality]) REFERENCES [dbo].[speciality]([Id])
)
