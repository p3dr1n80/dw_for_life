﻿CREATE TABLE [dbo].[speciality]
(
	[Id] INT NOT NULL PRIMARY KEY, 
    [name] VARCHAR(80) NOT NULL
)
