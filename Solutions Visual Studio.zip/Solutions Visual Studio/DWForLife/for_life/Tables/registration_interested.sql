﻿CREATE TABLE [dbo].[registration_interested]
(
	[id] [int] PRIMARY KEY NOT NULL,
	[name] [varchar](100) NOT NULL,
	[rg] [varchar](10) NULL,
	[cpf] [varchar](12) NOT NULL,
	[email] [varchar](100) UNIQUE NOT NULL,
	[cell_phone] [varchar](15) NULL,
	[birth] [date] NOT NULL,
	[gender] [varchar](1) NULL,
	[zip_code] [varchar](10) NOT NULL,
	[address] [varchar](80) NOT NULL,
	[number] [int] NOT NULL,
	[district] [varchar](80) NOT NULL,
	[city] [varchar](30) NOT NULL,
	[state] [varchar](2) NOT NULL,
	[complement] [varchar](80) NULL,
	[status] [int] NOT NULL,
	[created_at] [datetime] DEFAULT (GETDATE()) NOT NULL, 
    CONSTRAINT [FK_registration_interested_status] FOREIGN KEY ([status]) REFERENCES [dbo].[status]([id])
)
