﻿CREATE TABLE [dbo].[dim_services]
(
	[id] INT NOT NULL PRIMARY KEY,
	[name] VARCHAR(100) NOT NULL,
	[description] VARCHAR(200) NULL,
	[attendant] VARCHAR(80) NOT NULL
)
