﻿CREATE TABLE [dbo].[dim_time]
(
	  [cod_day] BIGINT PRIMARY KEY NOT NULL,
      [date] [date] NOT NULL,
      [cod_week] [int] NULL,
      [name_day_week] [varchar](50) NULL,
      [cod_month] [int] NULL,
      [name_month] [varchar](50) NULL,
      [cod_month_year] VARCHAR(50) NULL,
      [name_month_year] [varchar](50) NULL,
      [cod_quarter] [int] NULL,
      [name_quarter] [varchar](50) NULL,
      [cod_quarter_year] [varchar](50) NULL,
      [cod_semester] [int] NULL,
      [name_semester] [varchar](50) NULL,
      [cod_semester_year] [varchar](50) NULL,
      [year] [int] NULL,
      [day_type] [varchar](50) NULL,
)
