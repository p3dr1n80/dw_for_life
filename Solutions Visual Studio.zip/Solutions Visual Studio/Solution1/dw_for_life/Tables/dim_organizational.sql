﻿CREATE TABLE [dbo].[dim_organizational]
(
	[id] INT NOT NULL PRIMARY KEY,
	[name] VARCHAR(80) NOT NULL,
	[level] VARCHAR(50) NOT NULL,
	[speciality] VARCHAR(80) NOT NULL
)
