﻿CREATE TABLE [dbo].[fact_attendance]
(
	[id_patient] INT  NOT NULL,
	[id_organizational] INT  NOT NULL,
	[id_services] INT  NOT NULL,
	[id_time] BIGINT  NOT NULL,
	[most_serviced_locations] VARCHAR(2),
	[attendance_by_age] INT, 
    CONSTRAINT [FK_fact_attendance_dim_patient] FOREIGN KEY ([id_patient]) REFERENCES [dim_patient]([id]), 
    CONSTRAINT [FK_fact_attendance_dim_organizational] FOREIGN KEY ([id_organizational]) REFERENCES [dim_organizational]([id]), 
    CONSTRAINT [FK_fact_attendance_dim_services] FOREIGN KEY ([id_services]) REFERENCES [dim_services]([id]), 
    CONSTRAINT [FK_fact_attendance_dim_time] FOREIGN KEY ([id_time]) REFERENCES [dim_time]([cod_day]), 
    CONSTRAINT [PK_fact_attendance] PRIMARY KEY ([id_time], [id_services], [id_organizational], [id_patient])
)
