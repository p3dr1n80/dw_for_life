﻿CREATE TABLE [dbo].[dim_costs]
(
	[id] INT NOT NULL PRIMARY KEY,
	[local_costs] VARCHAR(30) NOT NULL,
)
