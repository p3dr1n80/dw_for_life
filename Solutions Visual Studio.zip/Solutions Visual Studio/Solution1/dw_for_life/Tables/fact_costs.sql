﻿CREATE TABLE [dbo].[fact_costs]
(
	[id_time] BIGINT NOT NULL,
	[id_costs] INT NOT NULL,
	[operational_costs] MONEY NOT NULL,
	[higher_costs] INT NOT NULL, 
    CONSTRAINT [PK_fact_costs] PRIMARY KEY ([id_time],[id_costs]), 
    CONSTRAINT [FK_fact_costs_dim_time] FOREIGN KEY ([id_time]) REFERENCES [dim_time]([cod_day]),
	CONSTRAINT [FK_fact_costs_dim_costs] FOREIGN KEY ([id_costs]) REFERENCES [dim_costs]([id])

)
