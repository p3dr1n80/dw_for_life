﻿CREATE TABLE [dbo].[dim_patient]
(
	[id] [int] PRIMARY KEY NOT NULL,
	[name] [varchar](100) NOT NULL,
	[birth] [date] NOT NULL,
	[gender] [varchar](10) NULL,
	[zip_code] [varchar](10) NOT NULL,
	[address] [varchar](80) NOT NULL,
	[number] [int] NOT NULL,
	[district] [varchar](80) NOT NULL,
	[city] [varchar](30) NOT NULL,
	[state] [varchar](2) NOT NULL,
	[state_description] VARCHAR(30) NULL,
	[complement] [varchar](80) NULL,
	[status] [int] NOT NULL,
)
