﻿CREATE TABLE [dbo].[fact_donations]
(
	[id_contributor] INT NOT NULL,
	[id_time] BIGINT NOT NULL,
	[values_donated] MONEY NOT NULL,
	[top_contributors] INT,
    CONSTRAINT [PK_fact_donations] PRIMARY KEY ([id_time], [id_contributor]), 
    CONSTRAINT [FK_fact_donations_dim_contributor] FOREIGN KEY ([id_contributor]) REFERENCES [dim_contributor]([id]), 
    CONSTRAINT [FK_fact_donations_dim_time] FOREIGN KEY ([id_time]) REFERENCES [dim_time]([cod_day])
)
