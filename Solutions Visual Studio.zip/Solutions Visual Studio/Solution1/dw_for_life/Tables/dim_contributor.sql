﻿CREATE TABLE [dbo].[dim_contributor]
(
	[id] INT NOT NULL PRIMARY KEY,
	[contributor] VARCHAR(100) NOT NULL,
	[donation] MONEY NOT NULL,
	[segment] VARCHAR(30) NOT NULL,
	[city] VARCHAR(30) NOT NULL,
	[state] VARCHAR(2) NOT NULL,
	[year_donation] INT NOT NULL
)
